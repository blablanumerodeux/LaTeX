./clean.sh ; pdflatex -shell-escape rapport.tex ; pdflatex -shell-escape rapport.tex 

