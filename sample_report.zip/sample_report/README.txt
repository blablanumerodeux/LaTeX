Exemple de rapport par Bruno Voisin (Hiko Seijûrô)
http://blog.hikoweb.net/


Tutorial Latex :
http://www.ukonline.be/programmation/latex/tutoriel/index.php
Page titre :
http://en.wikibooks.org/wiki/LaTeX/Title_Creation


### Pour installer LaTeX ###

sudo apt-get install texlive texlive-lang-french


### Pour générer le fichier PDF ###

# Près-requis : ajouter les droits d'exécution à make.sh et clean.sh
chmod +x make.sh clean.sh

./make.sh

# Nettoyer les fichiers temporaires :
./clean.sh



